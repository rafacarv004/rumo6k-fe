import React, { Component } from 'react';
import Nome from './Nome';
import Endereco from './Endereco';

//Pure Component or Class Component
class Campos extends Component {

  render() {
    return <Nome />;
  }
}

export default Campos;