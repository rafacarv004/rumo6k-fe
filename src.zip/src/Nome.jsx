import React, { Component } from 'react';

//Pure Component or Class Component
class Nome extends Component {

  constructor(props) {
    super(props);
    
    this.state = {
      nome: "Rafael",
      idade: "20"
    }
  }

  render() {
    const { nome, idade } = this.state;

    return(
      <div>
        <div> Oi! Eu sou o {nome}</div>
        <div> Eu tenho {idade} anos</div>
        <button onClick={this.changeName}>Mudar nome</button>
        <button onClick={this.changeAge}>Mudar idade</button>
      </div>
    );
  }

  changeName = () => {
    this.setState({
      nome: "Xablau"
    })
  }

  changeAge = () => {
    this.setState({
      idade: "30"
    })
  }
}

export default Nome;